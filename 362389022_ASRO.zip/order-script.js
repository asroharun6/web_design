document.addEventListener('DOMContentLoaded', function() {
    // Mengambil data pesanan dari Local Storage
    var order = JSON.parse(localStorage.getItem('order'));

    if (order) {
        var orderDetails = '<h1>Detail Pesanan</h1>' +
                           '<p>Nomor Pesanan: ' + order.id + '</p>' +
                           '<p>Nama: ' + order.name + '</p>' +
                           '<p>Email: ' + order.email + '</p>' +
                           '<p>Alamat: ' + order.address + '</p>' +
                           '<p>Telepon: ' + order.phone + '</p>';

        document.querySelector('.order-details').innerHTML = orderDetails;
    }
});
