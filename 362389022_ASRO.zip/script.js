let slideIndex = 0;
let cart = [];

// Fungsi untuk slideshow
function showSlides() {
    let i;
    let slides = document.getElementsByClassName("mySlides");
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";  
    }
    slideIndex++;
    if (slideIndex > slides.length) {slideIndex = 1}    
    slides[slideIndex-1].style.display = "block";  
    setTimeout(showSlides, 4000); // Ganti gambar setiap 4 detik
}

// Fungsi untuk mengatur tampilan keranjang
function toggleCart() {
    var cartElement = document.getElementById('cart');
    if (cartElement) {
        cartElement.style.display = cartElement.style.display === 'none' ? 'block' : 'none';
        updateCartUI();
    }
}

// Fungsi untuk menambahkan produk ke keranjang
function addToCart(productName, price) {
    let product = cart.find(item => item.productName === productName);
    if (product) {
        product.quantity += 1;
    } else {
        cart.push({ productName, price: parseFloat(price), quantity: 1 });
    }
    updateCartUI();
}

// Fungsi untuk memperbarui UI keranjang
function updateCartUI() {
    let cartItems = document.getElementById('cart-items');
    let cartCount = document.getElementById('cart-count');
    let cartTotal = document.getElementById('cart-total');

    if (cartItems && cartCount && cartTotal) {
        cartItems.innerHTML = '';
        let total = 0;
        cart.forEach(item => {
            total += item.price * item.quantity;
            let li = document.createElement('li');
            li.innerText = `${item.productName} - $${item.price} x ${item.quantity}`;
            cartItems.appendChild(li);
        });
        cartCount.innerText = cart.length;
        cartTotal.innerText = `Total: $${total.toFixed(2)}`;
    }
}

// Event listener untuk tombol Add to Cart
document.querySelectorAll('.product-item-buttons .btn-primary').forEach(button => {
    button.addEventListener('click', function() {
        var product = this.closest('.product');
        var productName = product.querySelector('h3').textContent;
        var price = product.querySelector('.product-price').textContent.replace('$', '');
        addToCart(productName, price);
    });
});

// Event listener untuk tombol Checkout
document.getElementById("checkout-button")?.addEventListener("click", () => {
    sessionStorage.setItem('cart', JSON.stringify(cart));
    window.location.href = 'pemesanan.html';
});

// Fungsi untuk menampilkan ringkasan pesanan di pemesanan.html
function displayOrderSummary() {
    const orderSummary = document.getElementById('order-summary');
    if (orderSummary) {
        const cart = JSON.parse(sessionStorage.getItem('cart') || '[]');
        let total = 0;

        if (cart.length === 0) {
            orderSummary.innerHTML = '<p>Keranjang belanja Anda kosong.</p>';
            return;
        }

        cart.forEach(item => {
            total += item.price * item.quantity;
            let p = document.createElement('p');
            p.innerText = `${item.productName} - $${item.price} x ${item.quantity}`;
            orderSummary.appendChild(p);
        });

        let totalElement = document.createElement('p');
        totalElement.innerText = `Total: $${total.toFixed(2)}`;
        orderSummary.appendChild(totalElement);
    }
}

// Inisialisasi fungsi tertentu ketika halaman dimuat
window.onload = function() {
    if (window.location.pathname.endsWith('gallery_barang.html')) {
        showSlides();
    } else if (window.location.pathname.endsWith('pemesanan.html')) {
        displayOrderSummary();
    }
};




document.getElementById('order-form').addEventListener('submit', function(event) {
    event.preventDefault();

    // Mengambil data dari form
    var customerName = document.getElementById('customer-name').value;
    var customerEmail = document.getElementById('customer-email').value;
    var customerAddress = document.getElementById('customer-address').value;
    var customerPhone = document.getElementById('customer-phone').value;

    // Membuat struktur data pesanan
    var order = {
        id: Date.now(), // Simple unique ID generator
        name: customerName,
        email: customerEmail,
        address: customerAddress,
        phone: customerPhone
    };

    // Menyimpan data ke Local Storage
    localStorage.setItem('order', JSON.stringify(order));

    // Redirect ke halaman konfirmasi
    window.location.href = 'data.html';
});
